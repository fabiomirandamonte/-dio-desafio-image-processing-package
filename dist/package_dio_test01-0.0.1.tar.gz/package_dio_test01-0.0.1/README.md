# Será utilizado o readme.md para exibir como a documentação na página do Pypo do seu pacote. # Foi usado markdown.

package_dio_test01

Description. package_name is used to: 
    Processing: 
        - Histogram matching 
        - Structural similarity 
        - Resize image Utils
    Utils:
        - Read image 
        - Save image 
        - Plot image 
        - Plot result 
        - Plot histogram

- Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name
# Utilizando o comando pip para instalar o package_name

        pip install image_processing

Author

Karina Kato

License